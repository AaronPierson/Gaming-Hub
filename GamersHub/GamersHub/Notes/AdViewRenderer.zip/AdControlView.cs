﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GamersHub.Controls
{
  public  class AdControlView : Xamarin.Forms.View
    {

      //  public enum Sizes { Standardbanner, LargeBanner, MediumRectangle, FullBanner, Leaderboard, SmartBannerPortrait }
      //  public Sizes Size { get; set; }
        public AdControlView()
        {
            //this.BackgroundColor = Color.Accent;
        }

       
    }
}
